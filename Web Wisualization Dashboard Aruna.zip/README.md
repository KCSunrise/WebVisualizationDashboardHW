
# Web Visualization Dashboard (Latitude-WeatherPy)

## https://kanikabhambi.github.io/web_visualization/

## Created a visualization dashboard website for the analysis of weather in different cities of the world across the globe.

This is an analysis and visualization of weather of 500+ cities across the world. The main objective was to showcase the relationship of various factors like temperature, humidity, cloudiness and wind speed with respect to the distance from the equator. 
